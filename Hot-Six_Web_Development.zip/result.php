<?php
	# 토큰 값 전송 확인
	if(!isset($_GET['token'])){
		Header("Location:/index.html");
	}

	# 토큰 존재 여부 확인
	if($_GET['token'] == NULL){
		echo "토큰이 존재하지 않습니다.";
		Header("Location:/index.html");
		exit();
	}
	$token = $_GET['token'];
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>핫식스 맛있다</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="/js/jquery.min.js"></script>
		<script src="/js/skel.min.js"></script>
		<script src="/js/skel-layers.min.js"></script>
		<script src="/js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="/css/skel.css" />
			<link rel="stylesheet" href="/css/style.css" />
			<link rel="stylesheet" href="/css/style-xlarge.css" />
		</noscript>
	</head>
	<body id="top">

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="/index.html">핫식스 맛있다</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="image.php">Activity Photos</a></li>
						<li><a href="#" class="button special">Sign Up</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner1">
				<div class="inner">
					<h2>쿠버네티스 취약점 분석 결과</h2>
					<p>K-Shield Jr 2 | 핫식스 맛있다</p>
				</div>
			</section>

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<h2>취약점 분석 목록</h2>
					<p>K-Shield Jr 2 | 핫식스 맛있다</p>

				</header>				
				<div class="container">
					<div class="row">
						<div class="12u">
							<section class="special box">
								<h2>취약점 리스트</h2>
						
								<h2>
<?php
	if($token = str_replace('@','',$token)){
		$token  = str_replace('.','',$token);
		include $_SERVER['DOCUMENT_ROOT']."/db/db_info.php";
		if(!$mysqli){
			die('not connect db');
		}

		include $_SERVER['DOCUMENT_ROOT']."/db/db_info.php";
		if(!$mysqli){
			die('not connect db');
		}

		$chk = "SELECT * from user WHERE email = '$token'";
		$res = $mysqli->query($chk);
		if(($row = $res->fetch_array(MYSQLI_BOTH))==false){
			echo "등록되지 않은 이메일입니다.<br />\n";
			echo "[<a href=/index.html>back page</a>]";
			exit();
		}

		$chk1 = "SELECT * from nodes WHERE id = '$row[0]'";
		$res1 = $mysqli->query($chk1);

		$chk2 = "SELECT * from detected_service WHERE id = '$row[0]'";
		$res2 = $mysqli->query($chk2);

		$chk3 = "SELECT * from vulnerability WHERE id = '$row[0]'";
		$res3 = $mysqli->query($chk3);

	//if($res1->num_rows==1){
		// $row1=$res1->fetch_array(MYSQLI_BOTH);
		// printf ("%s (%s)\n", $row1["Type"], $row1["Location"]);
		// $row1=$res1->fetch_array(MYSQLI_BOTH);
		// printf ("%s (%s)\n", $row1["Type"], $row1["Location"]);
		// $row1=$res1->fetch_array(MYSQLI_BOTH);
		// if($row1 == False){
		// 	echo "AAA";
		// }

	}else{
		echo "이메일 형식이 아닙니다.<br />\n";
		echo "[<a href=/index.html>back page</a>]";
	}
?>
								</h2>
								<table id="exp" style="text-align: center;">
									<tr>
										<th>CVE ver</th>
										<th>Security</th>
										<th>Security Score</th>
										<th>Publish Date</th>
										<th>Update Date</th>
										<th>Version</th>
									</tr>

									<tr>
										<td>CVE-2019-1002101</td>
										<td style="color: orange;">Medium</td>
										<td style="color: orange;">5.8</td>
										<td>2019-04-01</td>
										<td>2019-04-09</td>
										<td>1.14.0 ver</td>
									</tr>

									<tr>
										<td>CVE-2019-1002100</td>
										<td style="color: orange;">Medium</td>
										<td style="color: orange;">4.0</td>
										<td>2019-04-01</td>
										<td>2019-04-16</td>
										<td>1.13.4 ver</td>
									</tr>

									<tr>
										<td>CVE-2019-11244</td>
										<td style="color: green;">Normal</td>
										<td style="color: green;">1.9</td>
										<td>2019-04-22</td>
										<td>2019-05-09</td>
										<td>1.14.x ver</td>
									</tr>

									<tr>
										<td>CVE-2019-11243</td>
										<td style="color: orange;">Medium</td>
										<td style="color: orange;">4.3</td>
										<td>2019-04-22</td>
										<td>2019-05-09</td>
										<td>1.13.0 ver</td>
									</tr>

									<tr>
										<td>CVE-2019-9946</td>
										<td style="color: orange;">Medium</td>
										<td style="color: orange;">5.0</td>
										<td>2019-04-02</td>
										<td>2019-05-30</td>
										<td>1.14.0 ver</td>
									</tr>

									<tr>
										<td>CVE-2018-1002105</td>
										<td style="color: red;">High</td>
										<td style="color: red;">7.5</td>
										<td>2018-12-05</td>
										<td>2019-04-25</td>
										<td>1.12.3 ver</td>
									</tr>

									<tr>
										<td>CVE-2018-1002101</td>
										<td style="color: red;">High</td>
										<td style="color: red;">7.5</td>
										<td>2018-12-05</td>
										<td>2019-04-25</td>
										<td>1.11.1 ver</td>
									</tr>
								</table>
							</section>
						</div>
					</div>
			</section>

	<?php
		$ip_1 = "192.168.0.1"
	?>;
		<!-- Two -->
			<section id="two" class="wrapper style2">
				<header class="major">
					<h2>각 노드 취약점</h2>
					<p>K-Shield Jr 2 | 핫식스 맛있다</p>
				</header>
				<div class="container">
					<div class="row">
						<div class="12u">
							<section class="special box">
								<h2>Nodes</h2>
								<p class="popo">IP : <?php echo $ip_1 ?></p>
								<table id="exp_2" style="text-align: center;">
									<tr>
										<th class="t_h">TYPE</th>
										<th class="t_h">LOCATION</th>
									</tr>
	<?php
		while(($row1=$res1->fetch_array(MYSQLI_BOTH))){
		echo "<tr>";
		echo "<td>".$row1["types"]."</td>";
		echo "<td>".$row1["location"]."</td>";
		echo "</tr>";
		}
		$ip2 = "192.168.0.2";
	?>						
								</table>
						</div>
						<div class="12u">
							<section class="special box">
								<h2>Detectred Services</h2>
								<p class="popo">IP : <?php echo $ip2 ?></p>
								<table id="exp_2" style="text-align: center;">
									<tr>
										<th class="t_h">Service</th>
										<th class="t_h">Location</th>
									</tr>

	<?php
		while(($row2=$res2->fetch_array(MYSQLI_BOTH))){
		echo "<tr>";
		echo "<td>".$row2["service"]."</td>";
		echo "<td>".$row2["location"]."</td>";
		echo "</tr>";
		}	
		$ip3 = "192.168.0.3";
	?>	
								</table>
						</div>
						<div class="12u">
							<section class="special box">
								<h2>Vunlnerabilities</h2>
								<p class="popo">IP : <?php echo $ip3 ?></p>
								<table id="exp_2" style="text-align: center;">
									<tr>
										<th class="t_h">Location</th>
										<th class="t_h">Category</th>
										<th class="t_h">Vulnerability</th>
										<th class="t_h">Description</th>
										<th class="t_h">Evidence</th>
									</tr>
	<?php
		while(($row3=$res3->fetch_array(MYSQLI_BOTH))){
		echo "<tr>";
		echo "<td>".$row3["location"]."</td>";
		echo "<td>".$row3["category"]."</td>";
		echo "<td>".$row3["vulnerability"]."</td>";
		echo "<td>".$row3["description"]."</td>";
		echo "<td>".$row3["evidence"]."</td>";
		echo "</tr>";
		}	
	?>	
								</table>
						</div>
					</div>
				</div>
			</section>

		<!-- Three -->
			<section id="Three" class="wrapper style3">
				<header class="major">
					<h2>취약점 해결 방법</h2>
					<p>K-Shield Jr 2 | 핫식스 맛있다</p>
				</header>
				<div class="container">
					<div class="row">
						<div class="4u">
							<section class="special box">
								<h2>CVE-2019-1002101</h2>
								<p>kubectl
								다음의 취약점은 어떤 ~~가 취약하여 발생하는 취약점으로 보안 방법은로는 무엇무엇이 존재합니다 .</p>
							</section>
						</div>
						<div class="4u">
							<section class="special box">
								<h2>CVE-2019-11244</h2>
								<p>다음의 취약점은</p>
							</section>
						</div>
						<div class="4u">
							<section class="special box">
								<h2>CVE2019-9946</h2>
								<p>다음의 취약점은</p>
							</section>
						</div>
					</div>
				</div>
			</section>
	</body>
		<!-- Footer -->
	<footer id="footer">
		<div class="container">
			<div class="row double">
				<div class="6u">
					<div class="row collapse-at-2">
						<div class="6u">
							<h3>팀원 블로그 주소</h3>
							<ul class="alt">
								<li><a href="#">rjswn0315.tistory.com</a></li>
								<li><a href="#">pu1et-panggg.tistory.com</a></li>
								<li><a href="#">https://blog.naver.com/kng03470</a></li>
								<li><a href="#">없음</a></li>
								<li><a href="#">blog.naver.com/in_reasona</a></li>
							</ul>
						</div>
						<div class="6u">
							<h3>팀원 메일 주소</h3>
							<ul class="alt">
								<li><a href="#">rjswn1291@naver.com</a></li>
								<li><a href="#">pu1etproof@gmail.com</a></li>
								<li><a href="#">kng03470@naver.com</a></li>
								<li><a href="#">newpaper841@gmail.com</a></li>
								<li><a href="#">in_reasona@naver.com</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="6u">
					<h2>연구목적 및 주요내용</h2>
					<p>취약점이 적용된 쿠버네티스 프로그램에 CVE 취약점을 적용하며 분석하고, 공격 종류와 원리 파악 이후 취약한 코드를 보완할 방법을 모색하기 위해 개발하게 되었습니다. 쿠버네티스를 이용하는 많은 사람들에게 취약점 고취 및 취약점을 수정할 수 있는 시각 자료와 보안 메뉴얼을 제작합니다.</p>
					<p class="popo">Git 주소 : https://github.com/InReason/Delicious-Hot-Six</p>
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon fa-pinterest"><span class="label">Pinterest</span></a></li>
					</ul>
				</div>
			</div>
			<ul class="copyright">
				<li>&copy; Untitled. All rights reserved.</li>
				<li>Design: Reason</a></li>
				<li>Images: Hox-Six_Delicious</a></li>
			</ul>
		</div>
	</footer>
</html>