<?php
if(isset($_POST['token'])){
	$token  = $_POST['token'];
	$token  = str_replace('@','',$token);
	$token  = str_replace('.','',$token);

	include $_SERVER['DOCUMENT_ROOT']."/db/db_info.php";
	if(!$mysqli){
		die('not connect db');
	}

	$chk = "SELECT * from user WHERE email = '$token'";
	$res = $mysqli->query($chk);
	if($res->num_rows == 0){
		echo "1";  // 등록되지 않은 이메일 반환 값
		if($_POST['chk']==0){
			$sql = "insert into user (email)";
			$sql = $sql. "values('$token')";
			if($mysqli->query($sql)){
				echo "이메일 등록";
				exit();
			}else{
	 			echo "이메일 등록 실패";
				exit();
			}		
		}
	}

	if($_POST['chk']==1){
	$row=$res->fetch_array(MYSQLI_ASSOC);
	$id = $row['id'];		
		$type_1   = $_POST['Type_1'];
		$location_1 = $_POST['Location_1'];

		echo $type_1."\n";
		echo $location_1."\n";
		$sql = "INSERT INTO nodes (`id`, `types`, `location`)";
		$sql = $sql. "VALUES ('$id', '$type_1', '$location_1')";

		if($mysqli->query($sql)){
			echo "1번 취약점 분석 완료\n";
		}else{
			echo "1번 취약점 분석 실패\n";
		}
	}elseif($_POST['chk']==2){
	$row=$res->fetch_array(MYSQLI_ASSOC);
	$id = $row['id'];		$service_2  = $_POST['Service_2'];
		$location_2 = $_POST['Location_2'];

		$sql = "INSERT INTO detected_service (`id`, `service`, `location`)";
		$sql = $sql. "VALUES ('$id', '$service_2', '$location_2')";
		echo $service_2."\n";
		echo $location_2."\n";
		echo $sql."\n";
			if($mysqli->query($sql)){
				echo "2번 취약점 분석 완료\n";
			}else{
				echo "2번 취약점 분석 실패\n";
		}
	}elseif($_POST['chk']==3){
	$row=$res->fetch_array(MYSQLI_ASSOC);
	$id = $row['id'];		$location_3 = $_POST['Location_3'];
		$category_3 = $_POST['Category_3'];
		$vulnerability_3 = $_POST['Vulnerability_3'];
		$description_3   = $_POST['Description_3'];
		$evidence_3      = $_POST['Evidence_3'];
	
		$sql = "INSERT INTO vulnerability (`id`, `location`, `category`, `vulnerability`, `description`, `evidence`)";
		$sql = $sql. "VALUES ('$id', '$location_3', '$category_3', '$vulnerability_3', '$description_3', '$evidence_3')";
			if($mysqli->query($sql)){
				echo "3번 취약점 분석 완료\n";
			}else{
				die(mysqli_error($mysqli));
				echo "3번 취약점 분석 실패\n";
			}
	}else{
		echo "error";
	}
}else{
	echo 'to be not connect parameter';
}
?>

