create database pr

create table user(
id int(5) auto_increment NOT NULL,
email VARCHAR(20) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table nodes(
id int(5) NOT NULL,
types VARCHAR(20),
location VARCHAR(30),
foreign key(id) references user(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table detected_service(
id int(5) NOT NULL,
service VARCHAR(20),
location VARCHAR(30),
foreign key(id) references user(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table vulnerability(
id int(5) NOT NULL,
location VARCHAR(20),
category VARCHAR(20),
vulnerability VARCHAR(20),
description VARCHAR(30),
evidence VARCHAR(20),
foreign key(id) references user(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
