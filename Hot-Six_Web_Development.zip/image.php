<!DOCTYPE HTML>
<html>
	<head>
		<title>핫식스 맛있다</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="/js/jquery.min.js"></script>
		<script src="/js/skel.min.js"></script>
		<script src="/js/skel-layers.min.js"></script>
		<script src="/js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="/css/skel.css" />
			<link rel="stylesheet" href="/css/style.css" />
			<link rel="stylesheet" href="/css/style-xlarge.css" />
		</noscript>
	</head>
	<body id="top">

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="/index.html">핫식스 맛있다</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="#">No Sidebar</a></li>
						<li><a href="#" class="button special">Sign Up</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner1">
				<div class="inner">
					<h2>쿠버네티스 취약점 분석 결과</h2>
					<p>K-Shield Jr 2 | 핫식스 맛있다</p>
				</div>
			</section>

		<!-- One -->
			<section id="one" class="wrapper style1">
				<div class="container">
					<div class="row">
						<div class="12u">
							<section class="special box">
								<h2>활동 사진들</h2>
								<img width="30.5%" height="auto" src="images/file/noname01.PNG" alt="" /></a>

								<img width="30.5%" height="auto" src="images/file/noname02.jpg" alt="" /></a>
								<img width="30.5%" height="auto" src="images/file/noname04.jpg" alt="noname03.PNG" /></a>
								<img width="30.5%" height="auto" src="images/file/noname05.jpg" alt="noname04.PNG" /></a>
								<img width="30.5%" height="auto" src="images/file/noname06.jpg" alt="noname05.PNG" /></a>
								<img width="30.5%" height="auto" src="images/file/noname07.jpg" alt="noname06.PNG" /></a>
								<img width="30.5%" height="auto" src="images/file/noname08.jpg" alt="noname07.PNG" /></a>
							</section>
						</div>
					</div>
				</div>
			</section>
	</body>
</html>
