<?php
	$host = 'localhost';
	$user = 'root';
	$pw   = '1684';
	$db   = 'pr';
	$mysqli = new mysqli($host, $user, $pw, $db);
?>