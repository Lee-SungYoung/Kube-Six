<?php
	$token = $_GET['token'];
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>핫식스 맛있다</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="/js/jquery.min.js"></script>
		<script src="/js/skel.min.js"></script>
		<script src="/js/skel-layers.min.js"></script>
		<script src="/js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="/css/skel.css" />
			<link rel="stylesheet" href="/css/style.css" />
			<link rel="stylesheet" href="/css/style-xlarge.css" />
		</noscript>
	</head>
	<body id="top">

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="/index.html">핫식스 맛있다</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="#">No Sidebar</a></li>
						<li><a href="#" class="button special">Sign Up</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner1">
				<div class="inner">
					<h2>쿠버네티스 취약점 분석 결과</h2>
					<p>K-Shield Jr 2 | 핫식스 맛있다</p>
				</div>
			</section>

		<!-- One -->
			<section id="one" class="wrapper style1">
				<div class="container">
					<div class="row">
						<div class="12u">
							<section class="special box">
								<h2>이메일 등록 확인</h2>
								<p class="popo">토큰 값 : <?php echo $token ?></p>
								<h2><?php
	$salt = "@";
	if(strpos($token, $salt) == false){
		echo "이메일 형식이 아닙니다.<br />\n";
		echo "[<a href=/index.html>back page</a>]";
		exit();
	}
	if($token = str_replace('@','',$token)){
		$token  = str_replace('.','',$token);
		include $_SERVER['DOCUMENT_ROOT']."/db/db_info.php";
		if(!$mysqli){
			die('not connect db');
		}

		$sql = "SELECT * from user WHERE email = '$token'";
		$res = $mysqli->query($sql);
		if($res->num_rows == 0){
			# 등록 1
			$sql = "insert into user (email)";
			$sql = $sql. "values('$token')";
			if($mysqli->query($sql)){
				echo "이메일 등록.<br />\n";
				echo "[<a href=/index.html>back page</a>]";
				exit();
			}else{
	 			echo "이메일 등록 실패.<br />\n";
				echo "[<a href=/index.html>back page</a>]";
				exit();
			}
		}else{
			echo "등록된 이메일.<br />\n";
			echo "[<a href=/index.html>back page</a>]";
			exit();
		}	
	}
?>
